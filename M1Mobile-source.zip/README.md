# M1 Mobile — Android audio-engine prototype

This is an initial native Android project, not a finished Korg M1 emulator and not a reproduction of Korg PCM ROM.

## Included
- Kotlin Android app shell and simple program selector
- Native C++ audio renderer using Android OpenSL ES
- 32-voice oscillator-based prototype
- On-screen note input
- Basic reverb/chorus controls
- GitHub Actions workflow to build a debug APK

## Not yet implemented
- Original Korg PCM decoding or playback
- Korg program/combi SysEx parsing
- 8-part multitimbral mixer
- USB MIDI device enumeration and MIDI input/output
- Production DSP effects, filters, envelopes and modulation
- Low-latency Oboe backend and device testing

The program names are placeholders and the sound engine currently synthesizes waveforms. It must not be represented as containing original M1 samples.

## Build
Open this project in Android Studio, or push it to a GitHub repository and run the **Build M1 Mobile APK** workflow. The workflow uses the standard Gradle wrapper; add the Gradle wrapper files (`gradlew`, `gradlew.bat`, and `gradle/wrapper/gradle-wrapper.jar`) from a trusted Gradle installation before running Actions.
