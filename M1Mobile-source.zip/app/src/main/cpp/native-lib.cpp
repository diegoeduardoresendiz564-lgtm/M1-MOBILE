#include <jni.h>
#include <atomic>
#include <cmath>
#include <thread>
#include <vector>
#include <mutex>
#include <chrono>
#include <algorithm>
#include <android/log.h>
#include <SLES/OpenSLES.h>
#include <SLES/OpenSLES_Android.h>

static std::atomic<bool> running{false};
static std::thread audioThread;
static std::mutex voiceMutex;
struct Voice { int note=0; float phase=0; float amp=0; bool on=false; bool released=false; };
static Voice voices[32];
static float reverb=0.25f, chorus=0.15f;
static int program=0;
static SLObjectItf engineObject=nullptr, outputMixObject=nullptr, playerObject=nullptr;
static SLPlayItf playItf=nullptr;
static SLAndroidSimpleBufferQueueItf queueItf=nullptr;
static int16_t buffers[2][512];
static int bufferIndex=0;
static float delayLine[8192]={0}; static int delayPos=0;

static void render(int16_t* out, int frames) {
    std::lock_guard<std::mutex> lock(voiceMutex);
    for(int i=0;i<frames;i++) {
        float mix=0;
        for(auto &v:voices) if(v.on) {
            float freq=440.0f*powf(2.0f,(v.note-69)/12.0f);
            float sample=0;
            if(program==2) sample=(v.phase<0.03f?1.0f:-0.25f)*sinf(v.phase*6.2831853f);
            else if(program==1) sample=0.65f*sinf(v.phase*6.2831853f)+0.25f*sinf(v.phase*12.56637f);
            else if(program==3) sample=tanhf(2.0f*sinf(v.phase*6.2831853f));
            else sample=sinf(v.phase*6.2831853f);
            v.amp += (v.released ? -0.0008f : 0.0008f);
            if(v.amp<0) {v.on=false; continue;} v.amp=std::min(v.amp,0.18f);
            mix += sample*v.amp;
            v.phase += freq/44100.0f; if(v.phase>=1) v.phase-=1;
        }
        float delayed=delayLine[delayPos];
        delayLine[delayPos]=mix;
        delayPos=(delayPos+1)%8192;
        mix=(mix*(1.0f-reverb*0.25f)+delayed*reverb*0.25f);
        mix *= 1.0f+chorus*0.08f;
        int val=(int)(std::max(-1.0f,std::min(1.0f,mix))*32767);
        out[i*2]=out[i*2+1]=(int16_t)val;
    }
}
static void queueCallback(SLAndroidSimpleBufferQueueItf, void*) {
    if(!running) return;
    render(buffers[bufferIndex],256);
    (*queueItf)->Enqueue(queueItf,buffers[bufferIndex],sizeof(buffers[bufferIndex]));
    bufferIndex^=1;
}
static void startAudio() {
    if(running.exchange(true)) return;
    SLresult r;
    slCreateEngine(&engineObject,0,nullptr,0,nullptr,nullptr);
    (*engineObject)->Realize(engineObject,SL_BOOLEAN_FALSE);
    SLEngineItf engine;
    (*engineObject)->GetInterface(engineObject,SL_IID_ENGINE,&engine);
    (*engine)->CreateOutputMix(engine,&outputMixObject,0,nullptr,nullptr);
    (*outputMixObject)->Realize(outputMixObject,SL_BOOLEAN_FALSE);
    SLDataLocator_AndroidSimpleBufferQueue loc{SL_DATALOCATOR_ANDROIDSIMPLEBUFFERQUEUE,2};
    SLDataFormat_PCM fmt{SL_DATAFORMAT_PCM,2,SL_SAMPLINGRATE_44_1,SL_PCMSAMPLEFORMAT_FIXED_16,SL_PCMSAMPLEFORMAT_FIXED_16,SL_SPEAKER_FRONT_LEFT|SL_SPEAKER_FRONT_RIGHT,SL_BYTEORDER_LITTLEENDIAN};
    SLDataSource src{&loc,&fmt};
    SLDataLocator_OutputMix outLoc{SL_DATALOCATOR_OUTPUTMIX,outputMixObject};
    SLDataSink sink{&outLoc,nullptr};
    const SLInterfaceID ids[]={SL_IID_ANDROIDSIMPLEBUFFERQUEUE};
    const SLboolean req[]={SL_BOOLEAN_TRUE};
    (*engine)->CreateAudioPlayer(engine,&playerObject,&src,&sink,1,ids,req);
    (*playerObject)->Realize(playerObject,SL_BOOLEAN_FALSE);
    (*playerObject)->GetInterface(playerObject,SL_IID_PLAY,&playItf);
    (*playerObject)->GetInterface(playerObject,SL_IID_ANDROIDSIMPLEBUFFERQUEUE,&queueItf);
    (*queueItf)->RegisterCallback(queueItf,queueCallback,nullptr);
    (*playItf)->SetPlayState(playItf,SL_PLAYSTATE_PLAYING);
    render(buffers[0],256); (*queueItf)->Enqueue(queueItf,buffers[0],sizeof(buffers[0]));
    bufferIndex=1;
}
static void stopAudio() {
    running=false;
    if(playItf) (*playItf)->SetPlayState(playItf,SL_PLAYSTATE_STOPPED);
    if(playerObject) {(*playerObject)->Destroy(playerObject); playerObject=nullptr;}
    if(outputMixObject) {(*outputMixObject)->Destroy(outputMixObject); outputMixObject=nullptr;}
    if(engineObject) {(*engineObject)->Destroy(engineObject); engineObject=nullptr;}
    playItf=nullptr; queueItf=nullptr;
}
extern "C" JNIEXPORT void JNICALL Java_com_example_m1mobile_MainActivity_nativeStart(JNIEnv*,jobject){startAudio();}
extern "C" JNIEXPORT void JNICALL Java_com_example_m1mobile_MainActivity_nativeStop(JNIEnv*,jobject){stopAudio();}
extern "C" JNIEXPORT void JNICALL Java_com_example_m1mobile_MainActivity_nativeNoteOn(JNIEnv*,jobject,jint n,jint){std::lock_guard<std::mutex> l(voiceMutex); for(auto &v:voices) if(!v.on){v={n,0,0,true,false};break;}}
extern "C" JNIEXPORT void JNICALL Java_com_example_m1mobile_MainActivity_nativeNoteOff(JNIEnv*,jobject,jint n){std::lock_guard<std::mutex> l(voiceMutex);for(auto &v:voices)if(v.on&&v.note==n)v.released=true;}
extern "C" JNIEXPORT void JNICALL Java_com_example_m1mobile_MainActivity_nativeSetProgram(JNIEnv*,jobject,jint p){program=p;}
extern "C" JNIEXPORT void JNICALL Java_com_example_m1mobile_MainActivity_nativeSetReverb(JNIEnv*,jobject,jfloat a){reverb=a;}
extern "C" JNIEXPORT void JNICALL Java_com_example_m1mobile_MainActivity_nativeSetChorus(JNIEnv*,jobject,jfloat a){chorus=a;}
