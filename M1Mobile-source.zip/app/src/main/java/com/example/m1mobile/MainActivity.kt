package com.example.m1mobile

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import android.media.AudioTrack
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioAttributes
import android.media.AudioTrack.Builder
import android.media.AudioTrack.MODE_STREAM
import android.media.AudioDeviceInfo
import android.content.Context
import android.hardware.midi.MidiManager
import android.hardware.midi.MidiDeviceInfo
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private external fun nativeStart()
    private external fun nativeStop()
    private external fun nativeNoteOn(note: Int, velocity: Int)
    private external fun nativeNoteOff(note: Int)
    private external fun nativeSetProgram(program: Int)
    private external fun nativeSetReverb(amount: Float)
    private external fun nativeSetChorus(amount: Float)

    companion object { init { System.loadLibrary("m1mobile") } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = 0xff101820.toInt()
        window.navigationBarColor = 0xff101820.toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 22, 18, 18)
            setBackgroundColor(0xff101820.toInt())
        }
        fun label(s: String, size: Float, color: Int = 0xfff3f4f6.toInt()) =
            TextView(this).apply { text=s; textSize=size; setTextColor(color); gravity=Gravity.CENTER_VERTICAL }
        root.addView(label("M1 MOBILE", 28f))
        root.addView(label("SYNTHESIZER  •  ANDROID", 12f, 0xff8da6b8.toInt()))
        root.addView(label("Motor de audio nativo · prototipo funcional", 14f))
        val status = label("Audio: detenido", 13f, 0xff83d6b2.toInt())
        root.addView(status)
        val start = Button(this).apply { text="INICIAR MOTOR DE AUDIO" }
        start.setOnClickListener { nativeStart(); status.text="Audio: motor activo" }
        root.addView(start)
        val stop = Button(this).apply { text="DETENER AUDIO" }
        stop.setOnClickListener { nativeStop(); status.text="Audio: detenido" }
        root.addView(stop)
        root.addView(label("PROGRAMAS", 16f))
        val programs = arrayOf("Init Program", "Warm Pad", "Digital Bell", "Soft Bass")
        val spinner = Spinner(this).apply { adapter=ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, programs) }
        spinner.onItemSelectedListener = object: android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) { nativeSetProgram(position) }
        }
        root.addView(spinner)
        root.addView(label("TECLADO", 16f))
        val keys = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        for (n in 60..71) {
            val b=Button(this).apply { text=(n%12).toString(); textSize=10f; minWidth=0; setPadding(0,8,0,8) }
            b.setOnTouchListener { _, e ->
                when(e.action) {
                    android.view.MotionEvent.ACTION_DOWN -> nativeNoteOn(n, 100)
                    android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_CANCEL -> nativeNoteOff(n)
                }; true
            }
            keys.addView(b, LinearLayout.LayoutParams(0, 120, 1f))
        }
        root.addView(keys)
        root.addView(label("REVERB", 14f))
        val reverb=SeekBar(this).apply { max=100; progress=25; setOnSeekBarChangeListener(slider { nativeSetReverb(it/100f) }) }
        root.addView(reverb)
        root.addView(label("CHORUS", 14f))
        val chorus=SeekBar(this).apply { max=100; progress=15; setOnSeekBarChangeListener(slider { nativeSetChorus(it/100f) }) }
        root.addView(chorus)
        root.addView(label("MIDI USB: detección disponible en la siguiente integración", 12f, 0xffaab8c2.toInt()))
        setContentView(ScrollView(this).apply { addView(root) })
    }
    private fun slider(f:(Int)->Unit)=object: SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s:SeekBar?, p:Int, user:Boolean) { f(p) }
        override fun onStartTrackingTouch(s:SeekBar?) {}
        override fun onStopTrackingTouch(s:SeekBar?) {}
    }
    override fun onDestroy() { nativeStop(); super.onDestroy() }
}
